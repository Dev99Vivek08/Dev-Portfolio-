import { createClient } from "@supabase/supabase-js";

const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL || "";
const supabaseAnonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY || "";

export const supabase = createClient(supabaseUrl, supabaseAnonKey);
const hasSupabase = () => !!(supabaseUrl && supabaseAnonKey);

// ─── Auth ────────────────────────────────────────────────────────────────────
export async function signInAdmin(email: string, password: string) {
  if (!hasSupabase()) throw new Error("Supabase not configured");
  const { data, error } = await supabase.auth.signInWithPassword({ email, password });
  if (error) throw error;
  return data;
}
export async function signOutAdmin() {
  if (hasSupabase()) await supabase.auth.signOut();
}
export async function getAdminSession() {
  if (!hasSupabase()) return null;
  const { data } = await supabase.auth.getSession();
  return data.session;
}

// ─── Portfolio Config (hero, about, social, seo) ─────────────────────────────
export async function loadPortfolioConfig() {
  if (!hasSupabase()) return null;
  const { data } = await supabase.from("portfolio_config").select("*").limit(1).single();
  return data;
}
export async function savePortfolioConfig(config: Record<string, unknown>) {
  if (!hasSupabase()) throw new Error("Supabase not configured");
  const { data: existing } = await supabase.from("portfolio_config").select("id").limit(1).single();
  if (existing?.id) {
    const { error } = await supabase.from("portfolio_config").update({ ...config, updated_at: new Date().toISOString() }).eq("id", existing.id);
    if (error) throw error;
  } else {
    const { error } = await supabase.from("portfolio_config").insert([{ ...config }]);
    if (error) throw error;
  }
}

// ─── Projects ────────────────────────────────────────────────────────────────
export async function loadProjects() {
  if (!hasSupabase()) return null;
  const { data } = await supabase.from("projects").select("*").order("sort_order", { ascending: true });
  return data;
}
export async function saveProject(project: Record<string, unknown>) {
  if (!hasSupabase()) throw new Error("Supabase not configured");
  if (project.id) {
    const { error } = await supabase.from("projects").update({ ...project, updated_at: new Date().toISOString() }).eq("id", project.id);
    if (error) throw error;
  } else {
    const { error } = await supabase.from("projects").insert([{ ...project }]);
    if (error) throw error;
  }
}
export async function deleteProject(id: string) {
  if (!hasSupabase()) throw new Error("Supabase not configured");
  const { error } = await supabase.from("projects").delete().eq("id", id);
  if (error) throw error;
}

// ─── Skills ──────────────────────────────────────────────────────────────────
export async function loadSkills() {
  if (!hasSupabase()) return null;
  const { data } = await supabase.from("skills").select("*").order("sort_order", { ascending: true });
  return data;
}
export async function saveSkill(skill: Record<string, unknown>) {
  if (!hasSupabase()) throw new Error("Supabase not configured");
  if (skill.id) {
    const { error } = await supabase.from("skills").update(skill).eq("id", skill.id);
    if (error) throw error;
  } else {
    const { error } = await supabase.from("skills").insert([skill]);
    if (error) throw error;
  }
}
export async function deleteSkill(id: string) {
  if (!hasSupabase()) throw new Error("Supabase not configured");
  const { error } = await supabase.from("skills").delete().eq("id", id);
  if (error) throw error;
}

// ─── Blog Posts ──────────────────────────────────────────────────────────────
export async function loadBlogPosts() {
  if (!hasSupabase()) return null;
  const { data } = await supabase.from("blog_posts").select("*").order("created_at", { ascending: false });
  return data;
}
export async function saveBlogPost(post: Record<string, unknown>) {
  if (!hasSupabase()) throw new Error("Supabase not configured");
  if (post.id) {
    const { error } = await supabase.from("blog_posts").update({ ...post, updated_at: new Date().toISOString() }).eq("id", post.id);
    if (error) throw error;
  } else {
    const { error } = await supabase.from("blog_posts").insert([{ ...post }]);
    if (error) throw error;
  }
}
export async function deleteBlogPost(id: string) {
  if (!hasSupabase()) throw new Error("Supabase not configured");
  const { error } = await supabase.from("blog_posts").delete().eq("id", id);
  if (error) throw error;
}

// ─── File Upload ──────────────────────────────────────────────────────────────
export async function uploadFile(bucket: string, path: string, file: File): Promise<string> {
  if (!hasSupabase()) throw new Error("Supabase not configured");
  const { data, error } = await supabase.storage.from(bucket).upload(path, file, { upsert: true });
  if (error) throw error;
  const { data: urlData } = supabase.storage.from(bucket).getPublicUrl(data.path);
  return urlData.publicUrl;
}
