import type { Metadata } from "next";
import { Inter, JetBrains_Mono } from "next/font/google";
import "./globals.css";

const inter = Inter({
  subsets: ["latin"],
  variable: "--font-inter",
  weight: ["300", "400", "500", "600", "700", "800", "900"],
});

const jetbrainsMono = JetBrains_Mono({
  subsets: ["latin"],
  variable: "--font-mono",
  weight: ["400", "500", "700"],
});

export const metadata: Metadata = {
  title: "DEV.OS — Futuristic Portfolio",
  description: "A premium futuristic developer portfolio — immersive, cinematic, interactive.",
  keywords: ["developer", "portfolio", "fullstack", "react", "nextjs", "cyberpunk"],
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" className={`${inter.variable} ${jetbrainsMono.variable}`} style={{ background: "#050505" }}>
      <body className="antialiased bg-[#050505] text-white overflow-x-hidden">{children}</body>
    </html>
  );
}
