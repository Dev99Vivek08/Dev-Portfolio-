"use client";
import { useEffect, useRef, useState } from "react";
import { motion } from "framer-motion";
import dynamic from "next/dynamic";
import { defaultData } from "@/lib/data";

const ParticleField = dynamic(() => import("./ParticleField"), { ssr: false });

const roles = ["Full Stack Developer", "UI/UX Engineer", "3D Creative Dev", "System Architect"];

export default function Hero({ onTerminalClick }: { onTerminalClick: () => void }) {
  const [roleIndex, setRoleIndex] = useState(0);
  const [displayRole, setDisplayRole] = useState("");
  const [typing, setTyping] = useState(true);
  const heroRef = useRef<HTMLDivElement>(null);
  const avatarRef = useRef<HTMLDivElement>(null);
  const { hero } = defaultData;

  // Role cycling typewriter
  useEffect(() => {
    const role = roles[roleIndex];
    let i = 0;
    setDisplayRole("");
    setTyping(true);

    const typeInterval = setInterval(() => {
      if (i < role.length) {
        setDisplayRole(role.slice(0, i + 1));
        i++;
      } else {
        clearInterval(typeInterval);
        setTimeout(() => {
          setTyping(false);
          setTimeout(() => {
            setRoleIndex((prev) => (prev + 1) % roles.length);
          }, 500);
        }, 2200);
      }
    }, 60);

    return () => clearInterval(typeInterval);
  }, [roleIndex]);

  // Mouse parallax for avatar
  useEffect(() => {
    const handleMouse = (e: MouseEvent) => {
      if (!avatarRef.current) return;
      const rect = avatarRef.current.getBoundingClientRect();
      const cx = rect.left + rect.width / 2;
      const cy = rect.top + rect.height / 2;
      const dx = (e.clientX - cx) / window.innerWidth;
      const dy = (e.clientY - cy) / window.innerHeight;
      avatarRef.current.style.transform = `rotateY(${dx * 12}deg) rotateX(${-dy * 12}deg) translateY(${Math.sin(Date.now() / 1500) * 8}px)`;
    };
    window.addEventListener("mousemove", handleMouse);
    return () => window.removeEventListener("mousemove", handleMouse);
  }, []);

  // Floating animation
  useEffect(() => {
    let raf: number;
    const float = () => {
      if (avatarRef.current) {
        const t = Date.now() / 1500;
        const floating = Math.sin(t) * 8;
        avatarRef.current.dataset.float = floating.toString();
      }
      raf = requestAnimationFrame(float);
    };
    float();
    return () => cancelAnimationFrame(raf);
  }, []);

  const scrollToSection = (id: string) => {
    const el = document.querySelector(id);
    if (el) el.scrollIntoView({ behavior: "smooth", block: "start" });
  };

  return (
    <section ref={heroRef} className="relative min-h-screen flex items-center overflow-hidden" id="hero">
      {/* 3D Particle Background */}
      <ParticleField />

      {/* Vignette */}
      <div className="absolute inset-0 bg-gradient-radial from-transparent via-transparent to-[#050505]/80 z-[1]" />

      {/* Grid overlay */}
      <div className="absolute inset-0 grid-bg opacity-50 z-[1]" />

      {/* Content */}
      <div className="relative z-10 max-w-7xl mx-auto px-6 w-full pt-24">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center min-h-[80vh]">

          {/* Left — Text */}
          <div className="flex flex-col justify-center">
            {/* Status badge */}
            <motion.div
              initial={{ opacity: 0, x: -30 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.6, delay: 0.2 }}
              className="flex items-center gap-2 mb-8"
            >
              <span className="relative flex h-2 w-2">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-[#D9FF00] opacity-75" />
                <span className="relative inline-flex rounded-full h-2 w-2 bg-[#D9FF00]" />
              </span>
              <span className="font-mono text-xs text-[#9CA3AF] tracking-[0.25em] uppercase">
                Available for work
              </span>
            </motion.div>

            {/* Name */}
            <motion.h1
              initial={{ opacity: 0, y: 40 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.3, ease: [0.16, 1, 0.3, 1] }}
              className="text-5xl sm:text-6xl lg:text-7xl xl:text-8xl font-black leading-none tracking-tight mb-4"
              style={{ fontFamily: "var(--font-inter)" }}
            >
              {hero.name.split(" ").map((word, i) => (
                <span key={i} className={`block ${i === 1 ? "text-[#D9FF00]" : "text-white"}`}>
                  {word}
                </span>
              ))}
            </motion.h1>

            {/* Role typewriter */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.5 }}
              className="font-mono text-lg sm:text-xl text-[#9CA3AF] mb-2 h-8 flex items-center gap-1"
            >
              <span className="text-[#D9FF00] opacity-60">›</span>
              <span>{displayRole}</span>
              <span className={`text-[#D9FF00] ${typing ? "blink" : "opacity-0"}`}>_</span>
            </motion.div>

            {/* Tagline */}
            <motion.p
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.6 }}
              className="text-[#9CA3AF] text-base sm:text-lg leading-relaxed mb-10 max-w-md"
            >
              {hero.subtitle}
            </motion.p>

            {/* CTAs */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.7 }}
              className="flex flex-wrap gap-4"
            >
              <button
                onClick={() => scrollToSection("#projects")}
                className="group relative px-6 py-3 bg-[#D9FF00] text-black font-bold text-sm tracking-widest uppercase rounded overflow-hidden transition-all duration-300 hover:shadow-[0_0_30px_rgba(217,255,0,0.4)]"
              >
                <span className="relative z-10">View Projects</span>
                <div className="absolute inset-0 bg-white translate-y-full group-hover:translate-y-0 transition-transform duration-300" />
              </button>

              <button
                onClick={onTerminalClick}
                className="px-6 py-3 border border-[rgba(217,255,0,0.3)] text-[#D9FF00] font-mono text-sm tracking-widest uppercase rounded hover:bg-[rgba(217,255,0,0.06)] transition-all duration-300"
              >
                Open Terminal
              </button>
            </motion.div>

            {/* Social links */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 0.6, delay: 0.9 }}
              className="flex items-center gap-6 mt-10"
            >
              {[
                { label: "GitHub", href: defaultData.social.github },
                { label: "LinkedIn", href: defaultData.social.linkedin },
                { label: "Twitter", href: defaultData.social.twitter },
              ].map((s) => (
                <a
                  key={s.label}
                  href={s.href}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-[#9CA3AF] hover:text-[#D9FF00] text-xs tracking-widest uppercase transition-colors duration-200 font-mono"
                >
                  {s.label}
                </a>
              ))}
            </motion.div>
          </div>

          {/* Right — 3D Avatar */}
          <div className="flex items-center justify-center lg:justify-end">
            <motion.div
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 1, delay: 0.4, ease: [0.16, 1, 0.3, 1] }}
              className="relative"
            >
              {/* Glow rings */}
              <div className="absolute inset-0 flex items-center justify-center">
                <div className="w-80 h-80 rounded-full border border-[rgba(217,255,0,0.08)] animate-[spin_20s_linear_infinite]" />
                <div className="absolute w-64 h-64 rounded-full border border-[rgba(217,255,0,0.12)] animate-[spin_15s_linear_infinite_reverse]" />
                <div className="absolute w-96 h-96 rounded-full border border-[rgba(217,255,0,0.04)]" />
              </div>

              {/* Avatar container with 3D perspective */}
              <div
                ref={avatarRef}
                className="relative w-64 h-64 sm:w-80 sm:h-80 transition-transform duration-100"
                style={{ transformStyle: "preserve-3d", perspective: "1000px" }}
              >
                {/* Hex clip avatar */}
                <div
                  className="w-full h-full relative overflow-hidden"
                  style={{
                    clipPath: "polygon(50% 0%, 93% 25%, 93% 75%, 50% 100%, 7% 75%, 7% 25%)",
                    background: "linear-gradient(135deg, #111 0%, #1a1a1a 100%)",
                    border: "2px solid rgba(217,255,0,0.3)",
                  }}
                >
                  {/* Avatar image placeholder */}
                  <div className="w-full h-full flex items-center justify-center bg-gradient-to-br from-[#0a0a0a] to-[#1a1a1a]">
                    <div className="text-center">
                      <div className="text-6xl mb-2">👨‍💻</div>
                      <div className="font-mono text-xs text-[#D9FF00] opacity-60">AVATAR.PNG</div>
                    </div>
                  </div>

                  {/* Overlay shimmer */}
                  <div className="absolute inset-0 bg-gradient-to-tr from-transparent via-[rgba(217,255,0,0.03)] to-transparent" />
                </div>

                {/* Neon border glow */}
                <div
                  className="absolute inset-0 pointer-events-none"
                  style={{
                    clipPath: "polygon(50% 0%, 93% 25%, 93% 75%, 50% 100%, 7% 75%, 7% 25%)",
                    boxShadow: "0 0 40px rgba(217,255,0,0.2), 0 0 80px rgba(217,255,0,0.1)",
                  }}
                />
              </div>

              {/* Floating info cards */}
              <motion.div
                animate={{ y: [0, -8, 0] }}
                transition={{ duration: 3, repeat: Infinity, ease: "easeInOut" }}
                className="absolute -left-12 top-1/4 glass neon-border rounded px-3 py-2 hidden sm:block"
              >
                <div className="font-mono text-xs text-[#D9FF00]">5+ Years</div>
                <div className="font-mono text-[10px] text-[#9CA3AF]">Experience</div>
              </motion.div>

              <motion.div
                animate={{ y: [0, 8, 0] }}
                transition={{ duration: 3.5, repeat: Infinity, ease: "easeInOut", delay: 0.5 }}
                className="absolute -right-8 bottom-1/4 glass neon-border rounded px-3 py-2 hidden sm:block"
              >
                <div className="font-mono text-xs text-[#D9FF00]">80+ Projects</div>
                <div className="font-mono text-[10px] text-[#9CA3AF]">Shipped</div>
              </motion.div>
            </motion.div>
          </div>
        </div>

        {/* Scroll indicator */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1.5 }}
          className="absolute bottom-8 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2"
        >
          <span className="font-mono text-xs text-[#9CA3AF] tracking-[0.3em] uppercase">Scroll</span>
          <motion.div
            animate={{ y: [0, 8, 0] }}
            transition={{ duration: 1.5, repeat: Infinity }}
            className="w-px h-8 bg-gradient-to-b from-[#D9FF00] to-transparent"
          />
        </motion.div>
      </div>
    </section>
  );
}
