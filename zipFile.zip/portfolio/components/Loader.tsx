"use client";
import { useEffect, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";

const logs = [
  "Initializing system kernel...",
  "Connecting to secure server...",
  "Loading neural core modules...",
  "Mounting 3D asset pipeline...",
  "Authenticating user credentials...",
  "Decrypting portfolio data...",
  "Calibrating holographic renderer...",
  "Welcome back, DEV.",
];

interface LoaderProps {
  onComplete: () => void;
}

export default function Loader({ onComplete }: LoaderProps) {
  const [progress, setProgress] = useState(0);
  const [currentLogs, setCurrentLogs] = useState<string[]>([]);
  const [done, setDone] = useState(false);
  const [visible, setVisible] = useState(true);

  useEffect(() => {
    let logIndex = 0;
    const logInterval = setInterval(() => {
      if (logIndex < logs.length) {
        setCurrentLogs((prev) => [...prev, logs[logIndex]]);
        logIndex++;
      } else {
        clearInterval(logInterval);
      }
    }, 350);

    const progressInterval = setInterval(() => {
      setProgress((prev) => {
        if (prev >= 100) {
          clearInterval(progressInterval);
          setTimeout(() => {
            setDone(true);
            setTimeout(() => {
              setVisible(false);
              onComplete();
            }, 800);
          }, 400);
          return 100;
        }
        return prev + Math.random() * 4 + 1;
      });
    }, 80);

    return () => {
      clearInterval(logInterval);
      clearInterval(progressInterval);
    };
  }, [onComplete]);

  return (
    <AnimatePresence>
      {visible && (
        <motion.div
          key="loader"
          initial={{ opacity: 1 }}
          exit={{ opacity: 0, scale: 1.02 }}
          transition={{ duration: 0.8, ease: "easeInOut" }}
          className="fixed inset-0 z-[9999] bg-[#050505] flex flex-col items-center justify-center"
        >
          {/* Scanline overlay */}
          <div
            className="absolute inset-0 pointer-events-none"
            style={{
              backgroundImage: "repeating-linear-gradient(0deg, transparent, transparent 2px, rgba(0,0,0,0.03) 2px, rgba(0,0,0,0.03) 4px)",
            }}
          />

          <div className="w-full max-w-lg px-6 font-mono">
            {/* Logo */}
            <motion.div
              initial={{ opacity: 0, y: -20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
              className="mb-8 text-center"
            >
              <div className="text-[#D9FF00] text-3xl font-bold tracking-widest mb-1">DEV.OS</div>
              <div className="text-[#9CA3AF] text-xs tracking-[0.3em] uppercase">v2.0.26 // Neural Interface Active</div>
            </motion.div>

            {/* Log terminal */}
            <div className="bg-black/40 border border-[rgba(217,255,0,0.15)] rounded-sm p-4 mb-6 h-52 overflow-hidden relative">
              <div className="absolute top-0 left-0 right-0 h-px bg-[#D9FF00] opacity-30" />
              <div className="flex items-center gap-2 mb-3 pb-2 border-b border-white/5">
                <div className="w-2 h-2 rounded-full bg-[#D9FF00] opacity-60" />
                <span className="text-[#9CA3AF] text-xs tracking-widest">SYSTEM LOG // BOOT SEQUENCE</span>
              </div>
              <div className="space-y-1">
                {currentLogs.map((log, i) => (
                  <motion.div
                    key={i}
                    initial={{ opacity: 0, x: -10 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ duration: 0.3 }}
                    className={`text-xs flex items-start gap-2 ${
                      i === currentLogs.length - 1 && log === "Welcome back, DEV."
                        ? "text-[#D9FF00]"
                        : "text-[#9CA3AF]"
                    }`}
                  >
                    <span className="text-[#D9FF00] opacity-60 shrink-0">›</span>
                    <span>{log}</span>
                    {i === currentLogs.length - 1 && !done && (
                      <span className="blink text-[#D9FF00]">_</span>
                    )}
                  </motion.div>
                ))}
              </div>
            </div>

            {/* Progress bar */}
            <div className="mb-2">
              <div className="flex justify-between items-center mb-2">
                <span className="text-[#9CA3AF] text-xs tracking-widest">INITIALIZING</span>
                <span className="text-[#D9FF00] text-xs font-bold tracking-widest">
                  {Math.min(Math.round(progress), 100)}%
                </span>
              </div>
              <div className="h-px bg-white/5 relative overflow-hidden rounded-full">
                <motion.div
                  className="absolute top-0 left-0 h-full bg-[#D9FF00] rounded-full"
                  style={{ width: `${Math.min(progress, 100)}%` }}
                  animate={{ boxShadow: ["0 0 8px rgba(217,255,0,0.6)", "0 0 20px rgba(217,255,0,0.9)", "0 0 8px rgba(217,255,0,0.6)"] }}
                  transition={{ duration: 1, repeat: Infinity }}
                />
              </div>
            </div>

            {done && (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="text-center mt-4"
              >
                <span className="text-[#D9FF00] text-sm tracking-[0.3em] uppercase">System Ready</span>
              </motion.div>
            )}
          </div>

          {/* Corner decorations */}
          <div className="absolute top-4 left-4 border-l border-t border-[rgba(217,255,0,0.2)] w-8 h-8" />
          <div className="absolute top-4 right-4 border-r border-t border-[rgba(217,255,0,0.2)] w-8 h-8" />
          <div className="absolute bottom-4 left-4 border-l border-b border-[rgba(217,255,0,0.2)] w-8 h-8" />
          <div className="absolute bottom-4 right-4 border-r border-b border-[rgba(217,255,0,0.2)] w-8 h-8" />
        </motion.div>
      )}
    </AnimatePresence>
  );
}
