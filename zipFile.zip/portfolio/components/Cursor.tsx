"use client";
import { useEffect, useRef } from "react";

export default function Cursor() {
  const cursorRef = useRef<HTMLDivElement>(null);
  const followerRef = useRef<HTMLDivElement>(null);
  let mouseX = 0, mouseY = 0;
  let followerX = 0, followerY = 0;

  useEffect(() => {
    const move = (e: MouseEvent) => {
      mouseX = e.clientX;
      mouseY = e.clientY;
      if (cursorRef.current) {
        cursorRef.current.style.left = mouseX + "px";
        cursorRef.current.style.top = mouseY + "px";
      }
    };
    document.addEventListener("mousemove", move);

    let raf: number;
    const follow = () => {
      followerX += (mouseX - followerX) * 0.1;
      followerY += (mouseY - followerY) * 0.1;
      if (followerRef.current) {
        followerRef.current.style.left = followerX + "px";
        followerRef.current.style.top = followerY + "px";
      }
      raf = requestAnimationFrame(follow);
    };
    follow();

    const onEnter = () => {
      if (cursorRef.current) {
        cursorRef.current.style.width = "16px";
        cursorRef.current.style.height = "16px";
      }
      if (followerRef.current) {
        followerRef.current.style.width = "50px";
        followerRef.current.style.height = "50px";
      }
    };
    const onLeave = () => {
      if (cursorRef.current) {
        cursorRef.current.style.width = "10px";
        cursorRef.current.style.height = "10px";
      }
      if (followerRef.current) {
        followerRef.current.style.width = "36px";
        followerRef.current.style.height = "36px";
      }
    };

    document.querySelectorAll("a, button, [data-cursor]").forEach((el) => {
      el.addEventListener("mouseenter", onEnter);
      el.addEventListener("mouseleave", onLeave);
    });

    return () => {
      document.removeEventListener("mousemove", move);
      cancelAnimationFrame(raf);
    };
  }, []);

  return (
    <>
      <div ref={cursorRef} className="cursor" />
      <div ref={followerRef} className="cursor-follower" />
    </>
  );
}
