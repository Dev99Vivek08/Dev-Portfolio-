"use client";
import { useRef, useEffect, useState } from "react";
import { motion, useInView } from "framer-motion";
import { defaultData } from "@/lib/data";

function AnimatedStat({ value, label }: { value: string; label: string }) {
  const ref = useRef<HTMLDivElement>(null);
  const inView = useInView(ref, { once: true });

  return (
    <div ref={ref} className="text-center">
      <motion.div
        initial={{ opacity: 0, scale: 0.5 }}
        animate={inView ? { opacity: 1, scale: 1 } : {}}
        transition={{ duration: 0.5, type: "spring" }}
        className="text-3xl sm:text-4xl font-black text-[#D9FF00] mb-1"
      >
        {value}
      </motion.div>
      <div className="text-[#9CA3AF] text-xs font-mono tracking-widest uppercase">{label}</div>
    </div>
  );
}

export default function About() {
  const { about } = defaultData;
  const sectionRef = useRef<HTMLDivElement>(null);
  const inView = useInView(sectionRef, { once: true, margin: "-100px" });

  return (
    <section id="about" ref={sectionRef} className="relative py-32 overflow-hidden">
      {/* Background accent */}
      <div className="absolute top-0 right-0 w-96 h-96 bg-[#D9FF00] opacity-[0.02] rounded-full blur-3xl pointer-events-none" />

      <div className="max-w-7xl mx-auto px-6">
        {/* Section header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
          className="mb-20"
        >
          <div className="flex items-center gap-4 mb-4">
            <div className="w-8 h-px bg-[#D9FF00]" />
            <span className="font-mono text-xs text-[#D9FF00] tracking-[0.3em] uppercase">01 — About</span>
          </div>
          <h2 className="text-4xl sm:text-5xl lg:text-6xl font-black text-white">
            Who I Am
          </h2>
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-start">
          {/* Left: Bio + stats */}
          <div>
            <motion.p
              initial={{ opacity: 0, y: 20 }}
              animate={inView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.6, delay: 0.2 }}
              className="text-[#9CA3AF] text-lg leading-relaxed mb-10"
            >
              {about.bio}
            </motion.p>

            {/* Stats grid */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={inView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.6, delay: 0.3 }}
              className="grid grid-cols-2 sm:grid-cols-4 gap-6 p-6 glass neon-border rounded"
            >
              {about.stats.map((stat) => (
                <AnimatedStat key={stat.label} value={stat.value} label={stat.label} />
              ))}
            </motion.div>

            {/* Meta info */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={inView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.6, delay: 0.4 }}
              className="mt-8 space-y-3"
            >
              {[
                { label: "Location", value: about.location },
                { label: "Email", value: about.email },
                { label: "Status", value: about.availability },
              ].map((item) => (
                <div key={item.label} className="flex items-center gap-4">
                  <span className="font-mono text-xs text-[#D9FF00] tracking-widest w-20 uppercase shrink-0">
                    {item.label}
                  </span>
                  <div className="h-px flex-1 bg-white/5" />
                  <span className="text-[#9CA3AF] text-sm">{item.value}</span>
                </div>
              ))}
            </motion.div>
          </div>

          {/* Right: Timeline */}
          <div>
            <motion.h3
              initial={{ opacity: 0, y: 20 }}
              animate={inView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.6, delay: 0.2 }}
              className="font-mono text-xs text-[#D9FF00] tracking-[0.3em] uppercase mb-8"
            >
              Experience Timeline
            </motion.h3>

            <div className="relative pl-6 border-l border-white/10">
              {about.experience.map((exp, i) => (
                <motion.div
                  key={i}
                  initial={{ opacity: 0, x: 30 }}
                  animate={inView ? { opacity: 1, x: 0 } : {}}
                  transition={{ duration: 0.5, delay: 0.3 + i * 0.15 }}
                  className="relative mb-10 last:mb-0"
                >
                  {/* Timeline dot */}
                  <div className="absolute -left-[25px] top-1.5 w-3 h-3 rounded-full border border-[#D9FF00] bg-[#050505] flex items-center justify-center">
                    <div className="w-1.5 h-1.5 rounded-full bg-[#D9FF00]" />
                  </div>

                  <div className="glass neon-border rounded p-5 hover:border-[rgba(217,255,0,0.3)] transition-all duration-300 group">
                    <div className="flex items-start justify-between mb-2 flex-wrap gap-2">
                      <div>
                        <div className="text-white font-bold text-base">{exp.role}</div>
                        <div className="text-[#D9FF00] text-sm font-mono">{exp.company}</div>
                      </div>
                      <div className="font-mono text-xs text-[#9CA3AF] border border-white/10 px-2 py-1 rounded tracking-wide shrink-0">
                        {exp.year}
                      </div>
                    </div>
                    <p className="text-[#9CA3AF] text-sm leading-relaxed">{exp.description}</p>

                    {/* Hover accent */}
                    <div className="h-px mt-4 bg-gradient-to-r from-[#D9FF00] to-transparent scale-x-0 group-hover:scale-x-100 transition-transform duration-500 origin-left" />
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
