"use client";
import { useRef, useMemo } from "react";
import { Canvas, useFrame } from "@react-three/fiber";
import * as THREE from "three";

function Particles() {
  const meshRef = useRef<THREE.Points>(null);
  const count = 2000;

  const [positions, colors] = useMemo(() => {
    const positions = new Float32Array(count * 3);
    const colors = new Float32Array(count * 3);
    for (let i = 0; i < count; i++) {
      positions[i * 3] = (Math.random() - 0.5) * 20;
      positions[i * 3 + 1] = (Math.random() - 0.5) * 20;
      positions[i * 3 + 2] = (Math.random() - 0.5) * 10;

      const isLime = Math.random() > 0.7;
      colors[i * 3] = isLime ? 0.851 : 0.6;
      colors[i * 3 + 1] = isLime ? 1.0 : 0.6;
      colors[i * 3 + 2] = isLime ? 0.0 : 0.6;
    }
    return [positions, colors];
  }, []);

  useFrame((state) => {
    if (!meshRef.current) return;
    meshRef.current.rotation.y = state.clock.elapsedTime * 0.03;
    meshRef.current.rotation.x = Math.sin(state.clock.elapsedTime * 0.02) * 0.1;
  });

  return (
    <points ref={meshRef}>
      <bufferGeometry>
        <bufferAttribute attach="attributes-position" args={[positions, 3]} />
        <bufferAttribute attach="attributes-color" args={[colors, 3]} />
      </bufferGeometry>
      <pointsMaterial
        size={0.025}
        vertexColors
        transparent
        opacity={0.6}
        sizeAttenuation
      />
    </points>
  );
}

function FloatingOrb() {
  const meshRef = useRef<THREE.Mesh>(null);

  useFrame((state) => {
    if (!meshRef.current) return;
    meshRef.current.position.y = Math.sin(state.clock.elapsedTime * 0.5) * 0.3;
    meshRef.current.rotation.y = state.clock.elapsedTime * 0.2;
    meshRef.current.rotation.z = state.clock.elapsedTime * 0.1;
  });

  return (
    <mesh ref={meshRef} position={[2, 0, -2]}>
      <icosahedronGeometry args={[1.2, 1]} />
      <meshStandardMaterial
        color="#D9FF00"
        wireframe
        transparent
        opacity={0.15}
        emissive="#D9FF00"
        emissiveIntensity={0.3}
      />
    </mesh>
  );
}

function GridPlane() {
  return (
    <gridHelper
      args={[30, 30, "#D9FF00", "#1a1a1a"]}
      position={[0, -3, 0]}
      rotation={[0, 0, 0]}
    />
  );
}

export default function ParticleField() {
  return (
    <div className="absolute inset-0 z-0" style={{ pointerEvents: "none" }}>
      <Canvas
        camera={{ position: [0, 0, 8], fov: 60 }}
        gl={{ antialias: true, alpha: true }}
        style={{ background: "transparent" }}
      >
        <ambientLight intensity={0.3} />
        <pointLight position={[5, 5, 5]} color="#D9FF00" intensity={2} />
        <pointLight position={[-5, -5, -5]} color="#ffffff" intensity={0.5} />
        <Particles />
        <FloatingOrb />
        <GridPlane />
        <fog attach="fog" args={["#050505", 10, 30]} />
      </Canvas>
    </div>
  );
}
