"use client";
import { motion } from "framer-motion";

export default function Footer() {
  return (
    <footer className="relative border-t border-white/5 py-10">
      <div className="max-w-7xl mx-auto px-6 flex flex-col sm:flex-row items-center justify-between gap-4">
        <div className="font-mono text-xs text-[#9CA3AF] tracking-widest">
          © 2026 <span className="text-[#D9FF00]">Alex Chen</span>. All rights reserved.
        </div>

        <div className="flex items-center gap-2 font-mono text-xs text-[#9CA3AF]">
          <span className="relative flex h-1.5 w-1.5">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-[#D9FF00] opacity-75" />
            <span className="relative inline-flex rounded-full h-1.5 w-1.5 bg-[#D9FF00]" />
          </span>
          Built with Next.js · Framer Motion · R3F
        </div>

        <button
          onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })}
          className="font-mono text-xs text-[#9CA3AF] hover:text-[#D9FF00] tracking-widest uppercase transition-colors duration-200 flex items-center gap-2"
        >
          Back to top ↑
        </button>
      </div>
    </footer>
  );
}
