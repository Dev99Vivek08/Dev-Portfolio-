"use client";
import { useEffect, useRef, useState, useCallback } from "react";
import { motion, AnimatePresence } from "framer-motion";

interface TerminalProps {
  onMatrixMode: () => void;
  onGlitch: () => void;
  onAdminTrigger: () => void;
  autoFocus?: boolean;
}

type OutputLine = {
  type: "input" | "output" | "error" | "success" | "warning" | "system";
  content: string;
};

const COMMANDS: Record<string, (args: string[]) => OutputLine[]> = {
  help: () => [
    { type: "system", content: "═══════════════════════════════════════" },
    { type: "success", content: "  DEV.OS Terminal — Command Reference" },
    { type: "system", content: "═══════════════════════════════════════" },
    { type: "output", content: "  help          — Show this help menu" },
    { type: "output", content: "  about         — About the developer" },
    { type: "output", content: "  projects       — List all projects" },
    { type: "output", content: "  skills         — Display tech stack" },
    { type: "output", content: "  contact         — Contact information" },
    { type: "output", content: "  clear          — Clear terminal output" },
    { type: "output", content: "  theme lime     — Switch to lime theme" },
    { type: "output", content: "  theme matrix   — Activate matrix mode" },
    { type: "output", content: "  music on       — Enable ambient music" },
    { type: "output", content: "  music off      — Disable ambient music" },
    { type: "system", content: "───────────────────────────────────────" },
    { type: "warning", content: "  Hidden commands exist. Can you find them?" },
    { type: "system", content: "═══════════════════════════════════════" },
  ],
  about: () => [
    { type: "system", content: "═══════════════════════════════════════" },
    { type: "success", content: "  PROFILE // Alex Chen" },
    { type: "system", content: "═══════════════════════════════════════" },
    { type: "output", content: "  Role      › Full Stack Developer" },
    { type: "output", content: "  Location  › San Francisco, CA" },
    { type: "output", content: "  XP        › 5+ years" },
    { type: "output", content: "  Status    › Available for opportunities" },
    { type: "system", content: "───────────────────────────────────────" },
    { type: "output", content: "  Passionate full-stack developer" },
    { type: "output", content: "  specializing in React, Node.js & cloud." },
    { type: "system", content: "═══════════════════════════════════════" },
  ],
  projects: () => [
    { type: "system", content: "═══════════════════════════════════════" },
    { type: "success", content: "  PROJECTS // Selected Work" },
    { type: "system", content: "═══════════════════════════════════════" },
    { type: "output", content: "  [01] NeuralDash   — AI Analytics" },
    { type: "output", content: "       → github.com/alexchen/neuraldash" },
    { type: "output", content: "" },
    { type: "output", content: "  [02] CipherChat   — E2E Messaging" },
    { type: "output", content: "       → github.com/alexchen/cipherchat" },
    { type: "output", content: "" },
    { type: "output", content: "  [03] VoxForge     — 3D Audio Visual" },
    { type: "output", content: "       → github.com/alexchen/voxforge" },
    { type: "output", content: "" },
    { type: "output", content: "  [04] OrbitalDB    — Distributed DB" },
    { type: "output", content: "       → github.com/alexchen/orbitaldb" },
    { type: "system", content: "═══════════════════════════════════════" },
  ],
  skills: () => [
    { type: "system", content: "═══════════════════════════════════════" },
    { type: "success", content: "  SKILLS // Tech Arsenal" },
    { type: "system", content: "═══════════════════════════════════════" },
    { type: "output", content: "  Frontend  › React, Next.js, TypeScript" },
    { type: "output", content: "  Backend   › Node.js, Python, Rust" },
    { type: "output", content: "  Database  › PostgreSQL, Redis, MongoDB" },
    { type: "output", content: "  Cloud     › AWS, GCP, Docker, K8s" },
    { type: "output", content: "  3D/WebGL  › Three.js, R3F, GLSL" },
    { type: "output", content: "  Design    › Figma, Framer, GSAP" },
    { type: "system", content: "═══════════════════════════════════════" },
  ],
  contact: () => [
    { type: "system", content: "═══════════════════════════════════════" },
    { type: "success", content: "  CONTACT // Get In Touch" },
    { type: "system", content: "═══════════════════════════════════════" },
    { type: "output", content: "  Email    › alex@devportfolio.io" },
    { type: "output", content: "  GitHub   › github.com/alexchen" },
    { type: "output", content: "  LinkedIn › linkedin.com/in/alexchen" },
    { type: "output", content: "  Twitter  › @alexchendev" },
    { type: "system", content: "═══════════════════════════════════════" },
  ],
  clear: () => [],
  "music on": () => [
    { type: "success", content: "  ♪ Ambient mode activated. Focus unlocked." },
  ],
  "music off": () => [
    { type: "output", content: "  ♪ Ambient music disabled." },
  ],
  "theme lime": () => [
    { type: "success", content: "  ✓ Lime theme active. Looking sharp." },
  ],
  "theme matrix": () => [{ type: "system", content: "__MATRIX__" }],
  "glitch.dev": () => [{ type: "system", content: "__GLITCH__" }],
  "root.dev": () => [
    { type: "warning", content: "  ⚠ Escalating privileges..." },
    { type: "warning", content: "  ⚠ Bypassing security layer..." },
    { type: "error", content: "  ✗ ACCESS DENIED. Nice try." },
    { type: "output", content: "  Try a different approach..." },
  ],
  "awaken.system": () => [{ type: "system", content: "__ADMIN__" }],
};

const colorMap: Record<OutputLine["type"], string> = {
  input: "text-[#D9FF00]",
  output: "text-[#9CA3AF]",
  error: "text-red-400",
  success: "text-[#D9FF00]",
  warning: "text-yellow-400",
  system: "text-white/30",
};

export default function Terminal({ onMatrixMode, onGlitch, onAdminTrigger, autoFocus }: TerminalProps) {
  const [input, setInput] = useState("");
  const [history, setHistory] = useState<OutputLine[]>([
    { type: "system", content: "╔══════════════════════════════════════════╗" },
    { type: "system", content: "║        DEV.OS TERMINAL v2.0.26           ║" },
    { type: "system", content: "║    Secure Developer Interface Active     ║" },
    { type: "system", content: "╚══════════════════════════════════════════╝" },
    { type: "output", content: "" },
    { type: "output", content: '  Type "help" to see available commands.' },
    { type: "output", content: "" },
  ]);
  const [cmdHistory, setCmdHistory] = useState<string[]>([]);
  const [cmdHistoryIndex, setCmdHistoryIndex] = useState(-1);

  const inputRef = useRef<HTMLInputElement>(null);
  const bottomRef = useRef<HTMLDivElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [history]);

  useEffect(() => {
    if (autoFocus && inputRef.current) {
      inputRef.current.focus();
    }
  }, [autoFocus]);

  const processCommand = useCallback((cmd: string) => {
    const trimmed = cmd.trim().toLowerCase();
    const inputLine: OutputLine = { type: "input", content: `[dev@os ~]$ ${cmd}` };

    if (!trimmed) {
      setHistory((prev) => [...prev, inputLine]);
      return;
    }

    setCmdHistory((prev) => [trimmed, ...prev]);
    setCmdHistoryIndex(-1);

    const handler = COMMANDS[trimmed];
    if (!handler) {
      setHistory((prev) => [
        ...prev,
        inputLine,
        { type: "error", content: `  bash: ${trimmed}: command not found` },
        { type: "output", content: '  Type "help" for available commands.' },
      ]);
      return;
    }

    const output = handler([]);

    if (trimmed === "clear") {
      setHistory([]);
      return;
    }

    // Special system commands
    const hasMatrix = output.some((o) => o.content === "__MATRIX__");
    const hasGlitch = output.some((o) => o.content === "__GLITCH__");
    const hasAdmin = output.some((o) => o.content === "__ADMIN__");

    if (hasMatrix) {
      setHistory((prev) => [
        ...prev,
        inputLine,
        { type: "warning", content: "  ⚠ Initiating matrix protocol..." },
        { type: "success", content: "  ✓ Reality distortion active." },
      ]);
      setTimeout(onMatrixMode, 800);
      return;
    }

    if (hasGlitch) {
      setHistory((prev) => [
        ...prev,
        inputLine,
        { type: "warning", content: "  ⚠ Glitch sequence triggered..." },
        { type: "error", content: "  !! SYSTEM ANOMALY DETECTED !!" },
      ]);
      setTimeout(onGlitch, 400);
      return;
    }

    if (hasAdmin) {
      setHistory((prev) => [
        ...prev,
        inputLine,
        { type: "warning", content: "  ⚠ Hidden directive detected..." },
        { type: "warning", content: "  ⚠ Establishing secure channel..." },
        { type: "success", content: "  ✓ Admin interface unlocked." },
      ]);
      setTimeout(onAdminTrigger, 1000);
      return;
    }

    setHistory((prev) => [...prev, inputLine, ...output]);
  }, [onMatrixMode, onGlitch, onAdminTrigger]);

  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === "Enter") {
      processCommand(input);
      setInput("");
    } else if (e.key === "ArrowUp") {
      e.preventDefault();
      const newIndex = Math.min(cmdHistoryIndex + 1, cmdHistory.length - 1);
      setCmdHistoryIndex(newIndex);
      setInput(cmdHistory[newIndex] || "");
    } else if (e.key === "ArrowDown") {
      e.preventDefault();
      const newIndex = Math.max(cmdHistoryIndex - 1, -1);
      setCmdHistoryIndex(newIndex);
      setInput(newIndex === -1 ? "" : cmdHistory[newIndex]);
    }
  };

  return (
    <section id="terminal" className="relative py-32">
      <div className="max-w-7xl mx-auto px-6">
        {/* Section header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="mb-16"
        >
          <div className="flex items-center gap-4 mb-4">
            <div className="w-8 h-px bg-[#D9FF00]" />
            <span className="font-mono text-xs text-[#D9FF00] tracking-[0.3em] uppercase">04 — Terminal</span>
          </div>
          <h2 className="text-4xl sm:text-5xl lg:text-6xl font-black text-white mb-4">
            Developer Console
          </h2>
          <p className="text-[#9CA3AF] max-w-xl">
            An interactive terminal. Type commands to explore. Some commands are hidden.
          </p>
        </motion.div>

        {/* Terminal window */}
        <motion.div
          initial={{ opacity: 0, y: 40 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.7, delay: 0.2 }}
          className="relative rounded overflow-hidden"
          style={{
            boxShadow: "0 0 60px rgba(217,255,0,0.08), 0 0 120px rgba(217,255,0,0.04), 0 0 0 1px rgba(217,255,0,0.12)",
          }}
        >
          {/* Terminal titlebar */}
          <div className="flex items-center justify-between px-4 py-3 bg-[#0d0d0d] border-b border-white/5">
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 rounded-full bg-red-500/70" />
              <div className="w-3 h-3 rounded-full bg-yellow-500/70" />
              <div className="w-3 h-3 rounded-full bg-[#D9FF00]/70" />
            </div>
            <div className="font-mono text-xs text-[#9CA3AF] tracking-widest">DEV.OS TERMINAL — bash</div>
            <div className="font-mono text-xs text-[#D9FF00] opacity-60">● LIVE</div>
          </div>

          {/* Terminal body */}
          <div
            ref={containerRef}
            className="bg-[#080808] h-96 overflow-y-auto terminal-scroll p-4 font-mono text-xs leading-relaxed"
            onClick={() => inputRef.current?.focus()}
          >
            {/* Scanline overlay */}
            <div
              className="absolute inset-0 pointer-events-none opacity-30"
              style={{
                backgroundImage: "repeating-linear-gradient(0deg, transparent, transparent 2px, rgba(0,0,0,0.08) 2px, rgba(0,0,0,0.08) 4px)",
              }}
            />

            {/* Output lines */}
            <div className="space-y-0.5">
              {history.map((line, i) => (
                <div key={i} className={`${colorMap[line.type]} whitespace-pre-wrap break-all`}>
                  {line.content}
                </div>
              ))}
            </div>

            {/* Current input line */}
            <div className="flex items-center gap-0 mt-1 text-[#D9FF00]">
              <span className="shrink-0">[dev@os ~]$&nbsp;</span>
              <input
                ref={inputRef}
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={handleKeyDown}
                className="flex-1 bg-transparent text-[#D9FF00] outline-none border-none font-mono text-xs caret-[#D9FF00]"
                spellCheck={false}
                autoComplete="off"
                autoCorrect="off"
                autoCapitalize="off"
              />
              <span className="blink text-[#D9FF00] ml-0.5">█</span>
            </div>

            <div ref={bottomRef} />
          </div>

          {/* Terminal footer */}
          <div className="flex items-center justify-between px-4 py-2 bg-[#0d0d0d] border-t border-white/5">
            <div className="font-mono text-[10px] text-[#9CA3AF] tracking-widest">
              ↑↓ Navigate history &nbsp;·&nbsp; Enter to execute
            </div>
            <div className="font-mono text-[10px] text-[#D9FF00]/50">
              {history.length} lines
            </div>
          </div>
        </motion.div>

        {/* Quick commands hint */}
        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, delay: 0.5 }}
          className="flex flex-wrap gap-2 mt-6"
        >
          {["help", "about", "projects", "skills", "theme matrix"].map((cmd) => (
            <button
              key={cmd}
              onClick={() => {
                processCommand(cmd);
                inputRef.current?.focus();
              }}
              className="font-mono text-xs text-[#9CA3AF] border border-white/10 px-3 py-1.5 rounded hover:border-[rgba(217,255,0,0.3)] hover:text-[#D9FF00] transition-all duration-200"
            >
              {cmd}
            </button>
          ))}
        </motion.div>
      </div>
    </section>
  );
}
