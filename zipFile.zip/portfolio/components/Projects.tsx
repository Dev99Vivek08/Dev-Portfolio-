"use client";
import { useRef, useState } from "react";
import { motion, useInView } from "framer-motion";
import { defaultData } from "@/lib/data";

const categories = ["All", "AI", "Security", "Creative", "Backend"];

export default function Projects() {
  const { projects } = defaultData;
  const sectionRef = useRef<HTMLDivElement>(null);
  const inView = useInView(sectionRef, { once: true, margin: "-100px" });
  const [activeFilter, setActiveFilter] = useState("All");
  const [hoveredId, setHoveredId] = useState<number | null>(null);

  const filtered = activeFilter === "All" ? projects : projects.filter((p) => p.category === activeFilter);

  return (
    <section id="projects" ref={sectionRef} className="relative py-32 overflow-hidden">
      <div className="max-w-7xl mx-auto px-6">
        {/* Section header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
          className="mb-16"
        >
          <div className="flex items-center gap-4 mb-4">
            <div className="w-8 h-px bg-[#D9FF00]" />
            <span className="font-mono text-xs text-[#D9FF00] tracking-[0.3em] uppercase">02 — Projects</span>
          </div>
          <h2 className="text-4xl sm:text-5xl lg:text-6xl font-black text-white mb-4">
            Selected Work
          </h2>
          <p className="text-[#9CA3AF] max-w-xl">
            A curated selection of projects that showcase my technical range and design sensibility.
          </p>
        </motion.div>

        {/* Filter tabs */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6, delay: 0.2 }}
          className="flex flex-wrap gap-2 mb-12"
        >
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setActiveFilter(cat)}
              className={`font-mono text-xs tracking-widest uppercase px-4 py-2 rounded border transition-all duration-200 ${
                activeFilter === cat
                  ? "bg-[#D9FF00] text-black border-[#D9FF00]"
                  : "text-[#9CA3AF] border-white/10 hover:border-[rgba(217,255,0,0.3)] hover:text-white"
              }`}
            >
              {cat}
            </button>
          ))}
        </motion.div>

        {/* Projects grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {filtered.map((project, i) => (
            <motion.div
              key={project.id}
              initial={{ opacity: 0, y: 40 }}
              animate={inView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.5, delay: 0.1 + i * 0.1 }}
              onMouseEnter={() => setHoveredId(project.id)}
              onMouseLeave={() => setHoveredId(null)}
              className="group relative glass neon-border rounded overflow-hidden cursor-default"
              style={{
                boxShadow: hoveredId === project.id
                  ? "0 0 40px rgba(217,255,0,0.12), 0 0 80px rgba(217,255,0,0.06)"
                  : "none",
                transition: "box-shadow 0.4s ease",
              }}
            >
              {/* Image area */}
              <div className="relative h-48 overflow-hidden bg-gradient-to-br from-[#0d0d0d] to-[#1a1a1a]">
                {/* Project visual placeholder */}
                <div className="absolute inset-0 flex items-center justify-center">
                  <div className="text-center opacity-30 group-hover:opacity-50 transition-opacity duration-500">
                    <div className="font-mono text-6xl font-black text-[#D9FF00] leading-none">
                      {project.title.slice(0, 2).toUpperCase()}
                    </div>
                    <div className="w-20 h-px bg-[#D9FF00] mx-auto mt-2" />
                  </div>
                </div>

                {/* Category badge */}
                <div className="absolute top-4 left-4">
                  <span className="font-mono text-xs text-[#D9FF00] border border-[rgba(217,255,0,0.3)] bg-black/60 px-2 py-1 rounded tracking-widest">
                    {project.category}
                  </span>
                </div>

                {/* Featured badge */}
                {project.featured && (
                  <div className="absolute top-4 right-4">
                    <span className="font-mono text-xs text-black bg-[#D9FF00] px-2 py-1 rounded tracking-widest font-bold">
                      FEATURED
                    </span>
                  </div>
                )}

                {/* Hover overlay */}
                <div className="absolute inset-0 bg-gradient-to-t from-[#050505] via-transparent to-transparent opacity-60 group-hover:opacity-40 transition-opacity duration-300" />

                {/* Neon border top */}
                <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-[#D9FF00] to-transparent opacity-0 group-hover:opacity-40 transition-opacity duration-300" />
              </div>

              {/* Content */}
              <div className="p-6">
                <h3 className="text-xl font-bold text-white mb-2 group-hover:text-[#D9FF00] transition-colors duration-300">
                  {project.title}
                </h3>
                <p className="text-[#9CA3AF] text-sm leading-relaxed mb-4">
                  {project.description}
                </p>

                {/* Tags */}
                <div className="flex flex-wrap gap-2 mb-6">
                  {project.tags.map((tag) => (
                    <span
                      key={tag}
                      className="font-mono text-[10px] text-[#9CA3AF] border border-white/10 px-2 py-1 rounded tracking-wide"
                    >
                      {tag}
                    </span>
                  ))}
                </div>

                {/* Links */}
                <div className="flex items-center gap-4">
                  <a
                    href={project.github}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center gap-2 text-[#9CA3AF] hover:text-[#D9FF00] text-xs font-mono tracking-widest uppercase transition-colors duration-200 group/link"
                  >
                    <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 24 24">
                      <path d="M12 0c-6.626 0-12 5.373-12 12 0 5.302 3.438 9.8 8.207 11.387.599.111.793-.261.793-.577v-2.234c-3.338.726-4.033-1.416-4.033-1.416-.546-1.387-1.333-1.756-1.333-1.756-1.089-.745.083-.729.083-.729 1.205.084 1.839 1.237 1.839 1.237 1.07 1.834 2.807 1.304 3.492.997.107-.775.418-1.305.762-1.604-2.665-.305-5.467-1.334-5.467-5.931 0-1.311.469-2.381 1.236-3.221-.124-.303-.535-1.524.117-3.176 0 0 1.008-.322 3.301 1.23.957-.266 1.983-.399 3.003-.404 1.02.005 2.047.138 3.006.404 2.291-1.552 3.297-1.23 3.297-1.23.653 1.653.242 2.874.118 3.176.77.84 1.235 1.911 1.235 3.221 0 4.609-2.807 5.624-5.479 5.921.43.372.823 1.102.823 2.222v3.293c0 .319.192.694.801.576 4.765-1.589 8.199-6.086 8.199-11.386 0-6.627-5.373-12-12-12z" />
                    </svg>
                    GitHub
                  </a>
                  <a
                    href={project.live}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center gap-2 text-[#9CA3AF] hover:text-[#D9FF00] text-xs font-mono tracking-widest uppercase transition-colors duration-200"
                  >
                    <svg className="w-4 h-4" fill="none" stroke="currentColor" strokeWidth={2} viewBox="0 0 24 24">
                      <path d="M18 13v6a2 2 0 01-2 2H5a2 2 0 01-2-2V8a2 2 0 012-2h6M15 3h6v6M10 14L21 3" strokeLinecap="round" strokeLinejoin="round" />
                    </svg>
                    Live Demo
                  </a>
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        {/* View more */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={inView ? { opacity: 1 } : {}}
          transition={{ duration: 0.6, delay: 0.5 }}
          className="text-center mt-12"
        >
          <a
            href="https://github.com"
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-2 font-mono text-xs text-[#9CA3AF] hover:text-[#D9FF00] tracking-widest uppercase transition-colors duration-200 border border-white/10 hover:border-[rgba(217,255,0,0.3)] px-6 py-3 rounded"
          >
            View All on GitHub
            <span>→</span>
          </a>
        </motion.div>
      </div>
    </section>
  );
}
