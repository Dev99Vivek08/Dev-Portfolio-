"use client";
import { useRef, useState } from "react";
import { motion, useInView } from "framer-motion";
import { defaultData } from "@/lib/data";

const categories = ["All", "Frontend", "Backend", "Language", "Database", "DevOps", "Cloud", "API", "3D/WebGL", "Animation"];

export default function Skills() {
  const { skills } = defaultData;
  const sectionRef = useRef<HTMLDivElement>(null);
  const inView = useInView(sectionRef, { once: true, margin: "-100px" });
  const [activeCategory, setActiveCategory] = useState("All");

  const filtered = activeCategory === "All"
    ? skills
    : skills.filter((s) => s.category === activeCategory);

  const availableCategories = ["All", ...Array.from(new Set(skills.map((s) => s.category)))];

  return (
    <section id="skills" ref={sectionRef} className="relative py-32 overflow-hidden">
      {/* Background accent */}
      <div className="absolute bottom-0 left-0 w-96 h-96 bg-[#D9FF00] opacity-[0.02] rounded-full blur-3xl pointer-events-none" />

      <div className="max-w-7xl mx-auto px-6">
        {/* Section header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
          className="mb-16"
        >
          <div className="flex items-center gap-4 mb-4">
            <div className="w-8 h-px bg-[#D9FF00]" />
            <span className="font-mono text-xs text-[#D9FF00] tracking-[0.3em] uppercase">03 — Skills</span>
          </div>
          <h2 className="text-4xl sm:text-5xl lg:text-6xl font-black text-white mb-4">
            Tech Arsenal
          </h2>
          <p className="text-[#9CA3AF] max-w-xl">
            Tools and technologies I use to build exceptional digital experiences.
          </p>
        </motion.div>

        {/* Category filter */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6, delay: 0.2 }}
          className="flex flex-wrap gap-2 mb-12"
        >
          {availableCategories.map((cat) => (
            <button
              key={cat}
              onClick={() => setActiveCategory(cat)}
              className={`font-mono text-xs tracking-widest uppercase px-4 py-2 rounded border transition-all duration-200 ${
                activeCategory === cat
                  ? "bg-[#D9FF00] text-black border-[#D9FF00]"
                  : "text-[#9CA3AF] border-white/10 hover:border-[rgba(217,255,0,0.3)] hover:text-white"
              }`}
            >
              {cat}
            </button>
          ))}
        </motion.div>

        {/* Skills grid */}
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4">
          {filtered.map((skill, i) => (
            <motion.div
              key={skill.name}
              initial={{ opacity: 0, scale: 0.8, y: 20 }}
              animate={inView ? { opacity: 1, scale: 1, y: 0 } : {}}
              transition={{ duration: 0.4, delay: 0.1 + i * 0.05 }}
              whileHover={{ y: -6, scale: 1.03 }}
              className="group glass neon-border rounded p-4 flex flex-col items-center gap-3 cursor-default hover:border-[rgba(217,255,0,0.4)] hover:shadow-[0_0_20px_rgba(217,255,0,0.1)] transition-all duration-300"
            >
              <div className="text-3xl group-hover:scale-110 transition-transform duration-300">
                {skill.icon}
              </div>
              <div className="text-center">
                <div className="text-white text-xs font-semibold leading-tight">{skill.name}</div>
                <div className="text-[#9CA3AF] text-[10px] font-mono mt-0.5 tracking-wide">{skill.category}</div>
              </div>
              {/* Hover glow */}
              <div className="absolute inset-0 rounded opacity-0 group-hover:opacity-100 transition-opacity duration-300 pointer-events-none"
                style={{ background: "radial-gradient(circle at center, rgba(217,255,0,0.04) 0%, transparent 70%)" }}
              />
            </motion.div>
          ))}
        </div>

        {/* Bottom decorative element */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={inView ? { opacity: 1 } : {}}
          transition={{ duration: 0.6, delay: 0.5 }}
          className="mt-16 flex items-center gap-4"
        >
          <div className="h-px flex-1 bg-white/5" />
          <span className="font-mono text-xs text-[#9CA3AF] tracking-widest">Always learning. Always building.</span>
          <div className="h-px flex-1 bg-white/5" />
        </motion.div>
      </div>
    </section>
  );
}
